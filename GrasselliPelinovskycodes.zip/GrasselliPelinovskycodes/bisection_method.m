% bisection_method
clear all
a = 1; b = 2; ya = 2*log(a)+sqrt(a)-2; yb = 2*log(b)+sqrt(b)-2;
tolerance = 0.0000001; k = 1;
% iterations of the bisection method
while (abs(b-a) > tolerance)
    x(k) = (a+b)/2;
    y(k) = 2*log(x(k))+sqrt(x(k))-2;
    if (y(k) == 0)
        break;
    elseif (sign(y(k)) == sign(ya))
        a = x(k);
        ya = y(k);
    else
        b = x(k);
        yb = y(k);
    end
    k=k+1;
end
% approximation of the bisection method
fprintf('Root x = %12.10f found after %2.0f iterations \n',x(k-1),k-1);
