h = 0.1; x = -5 : h : 5; m = 0; 
s = input('Enter starting value for s = ');
ss = s; y(1) = 0; u(1) = s;     % (y,u) - components of y(x)
for k = 1 : length(x)-1         % iterations of the ODE solver
        yp = y(k) + h*u(k);
        up = u(k) + h*(x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2));
        y(k+1) = y(k) + 0.5*h*(u(k)+up);
        uu1 = x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2);
        uu2 = x(k+1)^2*yp+(3*x(k+1)^2-1)/((1+x(k+1)^2)^2);
        u(k+1) = u(k) + 0.5*h*(uu1 + uu2);
end
yy = y(length(x)); s = s + h;
while (abs(s-ss) > 10^(-10))             % iterations of the secant method
    m = m + 1; y(1) = 0; u(1) = s;
    for k = 1 : length(x)-1              % iterations of the ODE solver
        yp = y(k) + h*u(k);
        up = u(k) + h*(x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2));
        y(k+1) = y(k) + 0.5*h*(u(k)+up);
        uu1 = x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2);
        uu2 = x(k+1)^2*yp+(3*x(k+1)^2-1)/((1+x(k+1)^2)^2);
        u(k+1) = u(k) + 0.5*h*(uu1 + uu2);
    end
    if (m == 1)
        s = ss - h*yy/(y(length(x))-yy);
    else
        sN = s - (s - ss)*y(length(x))/(y(length(x))-yy);
        yy = y(length(x)); ss = s; s = sN;
    end
end
fprintf('The secant method converges after %d iteration(s)',m);
plot(x,y,'b'); 
 


