M = 100; x = linspace(0,1,1001);
for m = 1 : 2 : M
    j = 1 : m; b1 = 40*(1 - (-1).^j)./(pi^3*j.^3);
    xx = linspace(0,1,m+2); f = 10*xx.*(1-xx);
    for jj = 1 : m 
        b2(jj) = 2*f*sin(pi*jj*xx')/(m+1); 
    end 
    u1 = b1./(pi^2*j.^2); u2 = b2./(pi^2*j.^2);
    U1 = zeros(size(x)); U2 = zeros(size(x));
    for jj = 1 : m
        U1 = U1 + u1(jj)*sin(pi*jj*x);
        U2 = U2 + u2(jj)*sin(pi*jj*x);
    end
    Uexact = 5*x.*(x.^3-2*x.^2+1)/6;
    Error1((m+1)/2) = sqrt(sum((U1-Uexact).^2));
    Error2((m+1)/2) = sqrt(sum((U2-Uexact).^2));
end
m = 1 : 2 : M;   % power fit for the error dependence
a1 = polyfit(log(m),log(Error1),1); power1 = a1(1)
ErrorApr1 = exp(a1(2))*exp(power1*log(m));
a2 = polyfit(log(m),log(Error2),1); power2 = a2(1)
ErrorApr2 = exp(a2(2))*exp(power2*log(m)); 
plot(m,log(Error1),'b.',m,log(ErrorApr1),':g',m,log(Error2),'r.',m,log(ErrorApr2),':c')