x = 0 : 0.1 : 1; h = x(2)-x(1); n = length(x)-1; 
xInt = 0 : 0.001 : 1;               % intervals between breaking points
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end 
xx = xInt - x(iInt); y1 = x.^2; y0 = y1(1:n); 
m = diff(y1)./diff(x);              % linear splines
yInt1 = y0(iInt) + m(iInt).*xx; 
yEx1 = xInt.^2;                     % estimation of constant C1
C1 = max(yInt1-yEx1)/h^2
y2 = x.^3; y0 = y2(1:n);            % quadratic splines
firstDifference = (y2(2:n+1)-y2(1:n))./(x(2:n+1)-x(1:n));
m(1) = firstDifference(1); m(2) = m(1);
for k = 2 : n
    m(k+1) = -m(k)+2*firstDifference(k);
end
kappa = (m(2:n+1)-m(1:n))./(x(2:n+1)-x(1:n));
m = m(1:n);                         % estimation of constant C2
yInt2 = y0(iInt) + m(iInt).*xx+0.5*kappa(iInt).*xx.^2; 
yEx2 = xInt.^3; 
C2 = max(yInt2-yEx2)/h^3
y3 = x.^3.*(1-x/2);                 % cubic splines
h = x(2:n+1)-x(1:n); 
A = 2*diag(h(1:n-1)) + 2*diag(h(2:n)) + diag(h(2:n-1),1) + diag(h(2:n-1),-1);
b = 6*((y3(3:n+1)-y3(2:n))./h(2:n)-(y3(2:n)-y3(1:n-1))./h(1:n-1)); 
kappa = A\b'; kappa = [0;kappa;0]'; 
y0 = y3(1:n);                       % estimation of constant C3
m = (y3(2:n+1)-y3(1:n))./h(1:n)-h(1:n).*(kappa(2:n+1)+2*kappa(1:n))/6;
gamma = (kappa(2:n+1)-kappa(1:n))./h(1:n);  
% estimation of constant C3
yInt3 = y0(iInt) + m(iInt).*xx + 0.5*kappa(iInt).*xx.^2 + gamma(iInt).*xx.^3/6; 
yEx3 = xInt.^3.*(1-xInt/2);
C3 = 2*max(yInt3-yEx3)/h(1)^4