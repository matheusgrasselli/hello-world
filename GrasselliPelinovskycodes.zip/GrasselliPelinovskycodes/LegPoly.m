function c = LegPoly(p)
% computes coefficients of the decomposition of the given polynomial
% over the orthogonal set of Legendre polynomials
% p - vector for coefficients of the given polynomial p
% c - vector for coefficients of the orthogonal decomposition

m = length(p)-1;
for k = m : -1 : 1
    q = poly([ones(1,k),-ones(1,k)]);
    for kk = 1 : k
        q = polyder(q);
    end
    q = q/(factorial(k)*2^k);
    for kk = 1 : m-k
        q = [0,q];
    end
    c(m-k+1) = p(m-k+1)/q(m-k+1);
    p = p - c(m-k+1)*q;
end
c = [c,p(m+1)];
