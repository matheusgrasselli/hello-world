% multi_fixed_point
tol=0.0000001; total = 100; 
% fixed point iterations, first root
x=[-1.6;-0.6]; k = 0;epsilon=1;
while ((epsilon > tol) & (k < total))
    xnew = [1/x(2); -sqrt(x(1)+2)];
    epsilon = norm(xnew-x);
    x=xnew;
    k = k+1;
end
fprintf('x = %12.10f, y=%12.10f found after k= %2.0f iterations \n',x(1),x(2),k);


