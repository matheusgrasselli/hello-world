x = linspace(0.05,2.5,101); 
y = 5*x.^(0.25) + 2*(0.5-rand(size(x))); % given function
xBar = mean(log(x)); yBar = mean(log(y)); % sample mean
xSigma = mean((log(x)-xBar).^2);
ySigma = mean((log(y)-yBar).^2);
xySigma = mean((log(x)-xBar).*(log(y)-yBar)); % sample covariance
c1 = xySigma/xSigma; c2 = yBar - xBar*c1; % linear regression
c = exp(c2), p = c1, yApr = c*x.^(p); % power function
r = xySigma/sqrt(xSigma*ySigma) % correlation 
E = length(y)*ySigma*(1-r^2) % approximation error
figure(1); loglog(x,y,'g.',x,yApr,'b'); % linear regression in (log x,log y)
figure(2); plot(x,y,'g.',x,yApr,'b');  % nonlinear regression in (x,y)



