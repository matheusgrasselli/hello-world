function [Aprime,bprime] = gausselim(A,b)
% reduces general system A*x=b to equivalent
% upper triangular system Aprime*x=Bprime
% A :  n x n input matrix
% b :  n x 1 vector
% Aprime : n x n output matrix
% bprime : n x 1 output vector
% WARNING: possibility of division by zero

[n,m]=size(A);

for p = 1:n-1	              % loop through columns 
     for r=p+1:n             % loop down rows 
            M=A(r,p)/A(p,p);
            A(r,p)=0;
            A(r,p+1:n)=A(r,p+1:n)-A(p,p+1:n)*M;
            b(r)=b(r)-b(p)*M;
     end
end

Aprime=A;bprime=b;
