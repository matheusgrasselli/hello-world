m = 5; x = linspace(0,1,m+2);
f = 10*x.*(1-x);            % source term
for j = 1 : m
    b(j) = 2*f*sin(pi*j*x')/(m+1); 
end 
g = 0.2*sin(3*pi*x);        % initial condition
for j = 1 : m
    u(j) = 2*g*sin(pi*j*x')/(m+1); 
end 
j = 1:m; T = 0.5;
t = linspace(0,T,101); dt = t(2)-t(1);
uSpectrum(1,:) = u;
for k = 1 : length(t)-1     % time iterations
     k1 = -pi^2*j.^2.*u+b; u1 = u + 0.5*dt*k1;
     k2 = -pi^2*j.^2.*u1+b; u2 = u + 0.5*dt*k2;
     k3 = -pi^2*j.^2.*u2+b; u3 = u + dt*k3;
     k4 = -pi^2*j.^2.*u3+b;
     u = u + dt*(k1+2*k2+2*k3+k4)/6; 
     uSpectrum(k+1,:) = u;
end
x = linspace(0,1,101);
U = zeros(length(t),length(x)); 
for k = 1 : length(t)       % solution surface
    for jj = 1 : m
        U(k,:) = U(k,:) + uSpectrum(k,jj)*sin(pi*jj*x);
    end
end
kx = length(x); kt = length(t);
x = x(1:2:kx); t = t(1:2:kt);
U = U(:,1:2:kx); U = U(1:2:kt,:);
[X,T] = meshgrid(x,t); mesh(X,T,U); 
xlabel('x'); ylabel('t'); zlabel('u'); 
