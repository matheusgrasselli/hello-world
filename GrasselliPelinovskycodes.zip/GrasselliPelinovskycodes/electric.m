function e=electric(u,v)
% tangent vectors
tu=[2*cos(u)*cos(v);2*cos(u).*sin(v);-2*sin(u)];
tv=[-2*sin(u)*sin(v);2*sin(u)*cos(v);zeros(1,length(u))];
% normal vector 
N=cross(tu,tv);
% vector field evaluated on the sphere 
field=(10/(16*pi))*[sin(u)*cos(v);sin(u)*sin(v);cos(u)];
% normal component of the vector field 
for i=1:length(u)
    e(i)=field(:,i)'*N(:,i);
end



