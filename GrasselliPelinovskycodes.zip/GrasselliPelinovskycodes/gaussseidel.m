function [X,iter]=gaussseidel(A,B,tol,maxit)
% uses Gauss Seidel iteration to solve A*X=B
% A  	 square  n x n
% B  	 n x 1
% tol,maxit  tolerance, max no. of iterations

[n,m]=size(A);
X=0*B;		%initial guess
i=1;
iter=maxit;
for i = 1: maxit
	for j=1:n
		X(j)=(B(j)-A(j,1:j-1)*X(1:j-1)-A(j,j+1:n)*X(j+1:n))/A(j,j);
    end
    if norm(A*X-B) < tol
        iter=i;
		break
	end
end
