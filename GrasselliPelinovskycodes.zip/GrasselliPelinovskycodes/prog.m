function k=prog(a0,q,M)
% k is the number of steps necessary for the sum of
% terms of a geometric progression to become larger than a threshold M

x(1)=a0;
k=1;

while sum(x)<M
      x(k+1)=q*x(k);
      k=k+1;
end
