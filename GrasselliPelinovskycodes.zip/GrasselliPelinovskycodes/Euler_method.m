h = 0.1; y0 = 1; T = 3; n = T/h; 
t(1) = 0; y(1) = y0;
for k = 1 : n           % ODE (9.2)
    t(k+1) = t(k) + h;
	y(k+1) = y(k) + h*(-2*t(k)*y(k));
end
yExact = exp(-t.^2); eLocal = abs(y-yExact);
figure(1); plot(t,yExact,'r',t,y,'.b',t,eLocal,':g');  

h = 0.02; T = 0.94; n = T/h; 
clear t, clear y;
t(1) = 0; y(1) = y0;
for k = 1 : n           % ODE (9.3)
    t(k+1) = t(k) + h;
    y(k+1) = y(k) + h*y(k)^2;
end
yExact = 1./(1-t); eLocal = abs(y-yExact);
figure(2); plot(t,yExact,'r',t,y,'.b',t,eLocal,':g');  

