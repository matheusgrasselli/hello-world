n = 50; L = 20; omega = 0.5; h = (2*L)/n;
x = -L : h : L; y = -L : h : L; 
[X,Y] = meshgrid(x,y);
u = exp(-X.^2-Y.^2);    % starting approximation
u(1,:) = 0; u(n+1,:) = 0; u(:,1) = 0; u(:,n+1) = 0;
l = 0; nor = 1;
while( (nor > 10^(-8)) & (l < 100000))
    l = l + 1; uu = u;
    for k = 2 : n
        for m = 2 : n
            u(k,m) = (1-omega)*u(k,m)+0.25*omega*(u(k-1,m) ...
                + u(k+1,m) + u(k,m-1) + u(k,m+1) + h^2*u(k,m)^3);
        end
    end 
    power = sum(sum(u.^2));
    u = u/sqrt(power);
    nor = max(max(abs(u-uu)));
end
fprintf('Number of iterations for omega = %f is %d\n',omega,l);
Z = u; mesh(X,Y,Z); xlabel('x'); ylabel('y'); zlabel('u'); 
ux = (u(3:n+1,:)-u(1:n-1,:))/(2*h);   % partial derivatives
uy = (u(:,3:n+1)-u(:,1:n-1))/(2*h);   % Rayleigh quotient
lambda = (sum(sum(u.^4))-sum(sum(ux.^2))-sum(sum(uy.^2)))/sum(sum(u.^2))


