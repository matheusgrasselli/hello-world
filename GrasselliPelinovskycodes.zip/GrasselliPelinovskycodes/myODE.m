function dydx = myODE(x,y)
% function myODE defines the linear ODE
    dydx = [ y(2)
                x.^2.*y(1)-(1-3*x.^2)./(1+x.^2).^2];

