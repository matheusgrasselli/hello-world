m1 = 10; 
m2 = 30;
for m = m1 : m2
    x = linspace(0,6*pi/m,7); 
    y = sin(x);
    h(m-m1+1) = x(2)-x(1); 
    c = polyfit(x,y,6); 
    xInt = linspace(0,6*pi/m,100); 
    yInt = polyval(c,xInt);
    yExact = sin(xInt); 
    Error(m-m1+1) = max(abs(yExact-yInt)); 
end 
a = polyfit(log(h),log(Error),1);
power = a(1)
ErrorApr = exp(a(2))*exp(power*log(h));
plot(h,Error,'b.',h,ErrorApr,':g')