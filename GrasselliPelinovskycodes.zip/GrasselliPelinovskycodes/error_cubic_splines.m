x = 0 : 0.1 : 1; h = x(2)-x(1); n = length(x)-1; 
xInt = 0 : 0.001 : 1; 
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end 
y3 = x.^4; h = x(2:n+1)-x(1:n); 
A = 2*diag(h(1:n-1)) + 2*diag(h(2:n)) + diag(h(2:n-1),1) + diag(h(2:n-1),-1);
b = 6*((y3(3:n+1)-y3(2:n))./h(2:n)-(y3(2:n)-y3(1:n-1))./h(1:n-1)); 
b(n-1) = b(n-1) - 12*h(n);
kappa = A\b'; kappa = [0;kappa;12]'; 
y0 = y3(1:n);                   % cubic splines
m = (y3(2:n+1)-y3(1:n))./h(1:n)-h(1:n).*(kappa(2:n+1)+2*kappa(1:n))/6;
gamma = (kappa(2:n+1)-kappa(1:n))./h(1:n); 
xx = xInt - x(iInt); 
yInt3 = y0(iInt) + m(iInt).*xx + 0.5*kappa(iInt).*xx.^2 + gamma(iInt).*xx.^3/6; 
yEx3 = xInt.^4;
C3 = max(yInt3-yEx3)/h(1)^4