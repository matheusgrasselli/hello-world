% letter_grade script
% calculates final letter grade based on marks entered by user

x=input('Enter your term marks as a vector: ');

[m,s]=marks(x);

disp('   Your numerical average is:')
disp(m)

if m>= 80
   disp('Your final grade is A - well done !')
elseif (70<=m)&(m<79)
   disp('Your final grade is B')
elseif (60<=m)&(m<69)
   disp('Your final grade is C')
elseif (50<=m)&(m<59)
   disp('Your final grade is D')
else
   disp('Sorry, but with these marks you are failing the course')
end
