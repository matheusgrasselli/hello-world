for m = 1 : 300 
    x = linspace(-5,5,2*m+1); 
    y1 = 1./(1 + 25*x.^2);
    y2 = 1./(1 + x.^2); 
    n= 2*m; L = 10; 
    xx = [x(m+1:n),x(1:m)]'; 
    yy1 = [y1(m+1:n),y1(1:m)]';
    yy2 = [y2(m+1:n),y2(1:m)]';
    for j = 0 : m 
        a1(j+1) = 2*yy1'*cos(2*pi*j*xx/L)/n; 
        b1(j+1) = 2*yy1'*sin(2*pi*j*xx/L)/n; 
        a2(j+1) = 2*yy2'*cos(2*pi*j*xx/L)/n; 
        b2(j+1) = 2*yy2'*sin(2*pi*j*xx/L)/n; 
    end 
    xInt = linspace(-5,5,1001); 
    yInt1 = 0.5*a1(1)*ones(1,length(xInt)); 
    for j = 1 : (m-1)
        yInt1 = yInt1 + a1(1+j)*cos(2*pi*j*xInt/L) + b1(1+j)*sin(2*pi*j*xInt/L);
    end 
    yInt1 = yInt1 + 0.5*a1(m+1)*cos(2*pi*m*xInt/L);
    yInt2 = 0.5*a2(1)*ones(1,length(xInt)); 
    for j = 1 : (m-1)
        yInt2 = yInt2 + a2(1+j)*cos(2*pi*j*xInt/L) + b2(1+j)*sin(2*pi*j*xInt/L);
    end 
    yInt2 = yInt2 + 0.5*a2(m+1)*cos(2*pi*m*xInt/L);
    yExact1 = 1./(1 + 25*xInt.^2); 
    yExact2 = 1./(1 + xInt.^2); 
    Error1(m) = max(abs(yExact1-yInt1));
    Error2(m) = max(abs(yExact2-yInt2));
end 
semilogy(Error1,'b.'); hold on;
semilogy(Error2,'m.'); hold off;

