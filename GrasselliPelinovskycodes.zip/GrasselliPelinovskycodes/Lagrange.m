function yInt = Lagrange(x,y,xInt)
% performs Lagrange interpolation
% x,y - row vectors of the same size for data points
% xInt - row vector of any size for interpolated values
% yInt - row vector of the same size as xInt

n = length(x) - 1; 
ni = length(xInt);
L = ones(ni,n+1); % prepare a table of Lagrange polynomials
for j = 1 : (n+1) 
    for i = 1 : (n+1) 
        if (i ~= j) 
            L(:,j) = L(:,j).*(xInt' - x(i))/(x(j)-x(i));
        end
    end
end
yInt = y*L'; % compute the values of interpolations
