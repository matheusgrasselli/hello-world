t(1) = 0; yE(1) = 1; yH(1) = 1;
T = 18; h = 0.1; n = T/h;
for k = 1 : n       % iterations of two implicit methods
	t(k+1) = t(k) + h;
	yE(k+1) = yE(k)/(1+2*h*t(k+1));
    yH(k+1) = yH(k)*(1-h*t(k))/(1+h*t(k+1));
end   
yExact = exp(-t.^2); 
plot(t,yExact,':r',t,yE,'.b',t,yH,'.g'); axis([0,4,0,1]);
errorE = max(abs(yE-yExact)), errorH = max(abs(yH-yExact))




