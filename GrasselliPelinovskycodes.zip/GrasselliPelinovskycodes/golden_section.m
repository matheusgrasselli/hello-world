% golden_section
tol=0.000001;k=0;
options=optimset('TolX',tol); % sets the tolerance for fminbnd
[xmin,fmin]=fminbnd('x*sin(1/x)',0.15,0.5,options);
% iterations of the golden section search 
a=0.15; b=0.5;    % initial interval
s=(sqrt(5)-1)/2;  % golden section
a1=a+(1-s)*(b-a); % left intermediate point 
fa1=a1*sin(1/a1);  
b1=a+s*(b-a);     % right intermediate point
fb1=b1*sin(1/b1);
while (b-a > tol) 
 if fa1>fb1      % minimum must be to the right
    a=a1;      % left end point   
    a1=b1;     % left intermediate point
    fa1=fb1;
    b1=a+s*(b-a); % right intermediate point
    fb1=b1*sin(1/b1);  
 else          % minimum must be to the left
    b=b1;      % right end point
    b1=a1;     % right intermediate point
    fb1=fa1;
    a1=a+(1-s)*(b-a); % left intermediate point
    fa1=a1*sin(1/a1);
 end 
 x=b1;Error=abs(x-xmin);k=k+1;
end 
fprintf('x = %12.10f, Error= %12.10f, k= %2.0f \n',x,Error,k);
