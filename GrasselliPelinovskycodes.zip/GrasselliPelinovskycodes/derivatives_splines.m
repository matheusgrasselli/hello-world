x = -3:1:3; y = (cosh(x)).^(-2); 
yDer = -2*sinh(x).*(cosh(x)).^(-3);
xInt = -3 : 0.001 : 3; yEx = (cosh(xInt)).^(-2); 
yDerEx = -2*sinh(xInt).*(cosh(xInt)).^(-3);
                % semi-analytic computations of polynomials
[P1,R1] = unmkpp(spline(x,y));
[P2,R2] = unmkpp(pchip(x,y));
                % semi-analytic computations of their derivatives
[n,m] = size(R1);
for j = 1 : n
    Rder1(j,:) = polyder(R1(j,:));
end
yDerInt1 = ppval(mkpp(P1,Rder1),xInt);
[n,m] = size(R2);
for j = 1 : n
    Rder2(j,:) = polyder(R2(j,:));
end
yDerInt2 = ppval(mkpp(P2,Rder2),xInt);
plot(x,yDer,'r.',xInt,yDerEx,'r:',xInt,yDerInt1,'g',xInt,yDerInt2,'k');






