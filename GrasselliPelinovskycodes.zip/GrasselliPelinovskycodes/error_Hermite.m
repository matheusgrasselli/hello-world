xInt = linspace(0,1,1001);
for k = 2 : 4
    yEx = xInt.^k;
    for n = 1 : 50
        x = linspace(0,1,n+1); Step(n) = x(2)-x(1);
        y = x.^k; m = k*x.^(k-1); h = diff(x); 
        y0 = y(1:n); m0 = m(1:n);
        alpha = (diff(y)./h - m0)./h;
        beta = (m(2:n+1)+m(1:n)-2*diff(y)./h)./(h.^2); 
        for j = 1 : length(xInt)
	        if xInt(j) ~= x(n+1)
                iInt(j) = sum(x <= xInt(j));
	        else
		        iInt(j) = n;
	        end
        end
        xx = xInt-x(iInt);
        yInt=y0(iInt)+m0(iInt).*xx+alpha(iInt).*xx.^2;
        yInt=yInt+beta(iInt).*xx.^2.*(xInt-x(iInt+1));
        Error(n) = max(abs(yInt - yEx));
    end
    ErrorMax = max(Error)
    if (k == 4)
        a = polyfit(log(Step),log(Error),1);
        power = a(1) 
    end
end