function [y1] = ivpODE(t,y)
    y1 = -2*t.*y;  

