x = -1 : 0.2 : 3; n = length(x)-1; 
y = humps(x); h0 = 0.01; 
m = (humps(x+h0)-humps(x-h0))/(2*h0);       % slopes of the function "humps"
h = diff(x); y0 = y(1:n); m0 = m(1:n);
alpha = (diff(y)./h - m0)./h;               % coefficients of Hermite polynomials
beta = (m(2:n+1)+m(1:n)-2*diff(y)./h)./(h.^2);  
xInt = -1 : 0.001 : 3;                      % evaluations of Hermite polynomials
for j = 1 : length(xInt)
	if xInt(j) ~= x(n+1)
iInt(j) = sum(x <= xInt(j));
	else
		iInt(j) = n;
	end
end
xx = xInt-x(iInt); xx1 = xInt-x(iInt+1);
yInt = y0(iInt) + m0(iInt).*xx + alpha(iInt).*xx.^2 + beta(iInt).*xx.^2.*xx1;
yEx = humps(xInt);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:');  

