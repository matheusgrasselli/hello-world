h = 0.01; t(1) = 0; y(1) = 1; yExact(1) = 1;
t(2) = h; y(2) = 1/(1-t(2)); yExact(2) = y(2);  % no error for y_0 and y_1
E(1) = 0; E(2) = 0; k = 2;
while (t(length(t)) < 0.9)
    t(k+1) = t(k) + h;
	pp = y(k) + 0.5*h*(3*y(k)^2-y(k-1)^2);
    yy = y(k) + 0.5*h*(pp^2+y(k)^2);
    y(k+1) = yy;
    E(k+1) = abs(yy-pp)/6;      % error estimation formula
    yExact(k+1) = y(k)/(1-h*y(k));
    k = k+1; 
end
Eexact = abs(yExact-y);         % exact local error of a single step
semilogy(t,E,'.b',t,Eexact,':r'); 

