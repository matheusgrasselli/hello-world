function s=sum_squares(N)
% calculates the sum of squares for the first N integers

s=0;

for x=1:N
    s=s+x^2;
end