for n = 2 : 50;
    x = linspace(0,1,n+1); yExact = x.*(x.^3-1)./12;
    h = x(2:n+1)-x(1:n); hh(n-1) = h(1);
                        % finite-element methods
    d1 = (1./h(1:n-1)+1./h(2:n)); d2 = -1./h(2:n-1);
    A = diag(d1) + diag(d2,-1) + diag(d2,+1);
    b = -(x(3:n+1).^3-x(1:n-1).^3+x(2:n).*(x(3:n+1).^2-x(1:n-1).^2))/12; 
    b = b-x(2:n).^2.*(x(3:n+1)-x(1:n-1))/12;
    y = A\b'; y = [0,y',0];
    errFEM(n-1) = max(abs(y-yExact));
                        % finite-difference method
    A = 2*diag(ones(1,n-1)) - diag(ones(1,n-2),1) - diag(ones(1,n-2),-1);
    b = -hh(n-1)^2*x(2:n).^2;
    y = A\b'; y = [0,y',0];
    errFDM(n-1) = max(abs(y-yExact));
end
a = polyfit(log(hh),log(errFDM),1); % power fit
power = a(1), MaxErrFDM = max(errFDM), MaxErrFEM = max(errFEM)