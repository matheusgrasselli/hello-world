function [s,x]=squares(N)
% squares of the first N integers and their sum

for k=1:N
    x(k)=k^2;
end

s=sum(x);