x = -1 : 0.2 : 3;  n = length(x)-1; y = humps(x); 
y0 = y(1:n); m = diff(y)./diff(x);      % slopes of linear splines
xInt = -1 : 0.001 : 3; 
for j = 1 : length(xInt)                % intervals between breaking points
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end 
yInt = y0(iInt) + m(iInt).*(xInt-x(iInt)); 
yEx = humps(xInt); figure(1);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:'); 
axis([-1,3,-10,100]);

figure(2)
plot(x,y,'b.',x,y,'g',xInt,yEx,'r:');