figure(1); hold on; 
for n = 4 : 4 : 12 
    x = linspace(-1,1,n+1); 
    y = 1./(1+25*x.^2);
    m = n/2; L = 2; 
    xx = [x(m+1:n),x(1:m)]'; 
    yy = [y(m+1:n),y(1:m)]';
    for j = 0 : m       % coefficients of interpolation
        a(j+1) = 2*yy'*cos(2*pi*j*xx/L)/n; 
        b(j+1) = 2*yy'*sin(2*pi*j*xx/L)/n; 
    end
    xInt = -1 : 0.001 : 1; 
    yInt = 0.5*a(1)*ones(1,length(xInt)); 
    for j = 1 : (m-1)   % trigonometric interpolant
        yInt = yInt + a(1+j)*cos(2*pi*j*xInt/L) + b(1+j)*sin(2*pi*j*xInt/L);
    end 
    yInt = yInt + 0.5*a(m+1)*cos(2*pi*m*xInt/L);
    plot(xInt,yInt,x,y,'.'); 
end
yExact = 1./(1+25*xInt.^2);
plot(xInt,yExact,':r'); hold off;