% central_differences
n = 50;
x = linspace(0,2*pi,n);
h = x(2)-x(1);
y = sin(x);
y1 = (diff(y(2:n))+diff(y(1:n-1)))/(2*h);
y2 = (diff(y1(2:n-2))+diff(y1(1:n-3)))/(2*h);
y1ex = cos(x);
y2ex = -sin(x);
plot(x(2:n-1),y1,'b',x,y1ex,':r',x(3:n-2),y2,'g',x,y2ex,':r');
