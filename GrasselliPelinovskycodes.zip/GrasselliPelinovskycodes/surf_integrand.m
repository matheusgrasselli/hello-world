function g=surf_integrand(x,y)
% curl of the vector field evaluated on the surface:
g=(3*x.^2*y^2-5*x.^2*y^4).*((x.^2+y.^2)<=1);  