% steepest
tol = 0.000001; total = 100; k = 0; epsilon = 1;
x = [-1;0]; % initial guess 
% gradient calculated at the initial guess
s=[(1-2*x(1)^2)*x(2)*exp(-x(1)^2-x(2)^2);(1-2*x(2)^2)*x(1)*exp(-x(1)^2-x(2)^2)];
while ((epsilon > tol) & (k < total)) % steepest descent method
    tmin=fminsearch(@(t)(x(1)-t*s(1))*(x(2)-t*s(2))*exp(-(x(1)-t*s(1))^2-(x(2)-t*s(2))^2),1);
    xnew = x-tmin*s;
    x=xnew; 
    s=[(1-2*x(1)^2)*x(2)*exp(-x(1)^2-x(2)^2);(1-2*x(2)^2)*x(1)*exp(-x(1)^2-x(2)^2)];
    epsilon=norm(s);
    k = k+1;
end
fprintf('Minimum found at x = %12.10f, y=%12.10f after %2.0f iterations \n',...
    x(1),x(2),k);
