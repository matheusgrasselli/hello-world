% instability_explicit_method
h = 0.1; x = 0 : h : 2; n = length(x) - 1;
tau = 0.55*0.01; t = 0 : tau : 1.28; r = tau/h^2;
U1 = zeros(length(x),length(t)); U1(:,1) = sin(pi*x');  
A1 = (1 - 2*r)*diag(ones(1,n-1)) + r*(diag(ones(1,n-2),1)+diag(ones(1,n-2),-1));
for k = 1 : (length(t)-1)
    U1(2:n,k+1) = A1*U1(2:n,k);
end
[T,X] = meshgrid(t,x); surf(X,T,U1); 
xlabel('x'); ylabel('t'); zlabel('u'); 