function norm=my_norm(A)
% calculates the max absolute row sum for the matrix A

[m,n]=size(A);

largest=0;

for i=1:m        % loop along rows
    row_sum=0;

    for j=1:n    % loop along columns
        row_sum=row_sum+abs(A(i,j));
    end

    if row_sum>=largest
       largest=row_sum;
    end
end

norm=largest;