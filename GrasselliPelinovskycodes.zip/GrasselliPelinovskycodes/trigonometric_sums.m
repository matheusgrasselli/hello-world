x = -1 : 0.25 : 1; y = sign(x);
n = length(x) - 1; m = n/2; L = 2;
y(1) = 0; y(n+1) = 0;       % continuation of data to x in [0,L]
xx = [x(m+1:n),x(1:m)]'; yy = [y(m+1:n),y(1:m)]';
A = 0.5*ones(n,1);          % building the coefficient matrix
for j = 1 : (m-1)
        A = [ A, cos(2*pi*j*xx/L), sin(2*pi*j*xx/L) ];
end 
A = [ A, 0.5*cos(2*pi*m*xx/L) ];
c = A\yy;                   % Fourier coefficients of interpolation
a = [c(1);c(2:2:n)]', b = [0;c(3:2:n);0]' 
bb = 0; jj = 1;             % Fourier coefficients of approximation
for j = 1 : m-1
    if (jj == 1) 
        bb = [bb,4/(pi*j)]; jj = 0;
    else
        bb = [bb,0]; jj = 1;
    end
end
xInt = -1: 0.002 : 1; 
yInt = 0.5*a(1)*ones(1,length(xInt)); 
for j = 1 : (m-1)           % trigonometric interpolation
    yInt = yInt + a(1+j)*cos(2*pi*j*xInt/L) + b(1+j)*sin(2*pi*j*xInt/L);
end 
yInt = yInt + 0.5*a(m+1)*cos(2*pi*m*xInt/L);
yyInt = zeros(1,length(xInt)); % trigonometric approximation
for j = 1 : (m-1)
    yyInt = yyInt + bb(1+j)*sin(2*pi*j*xInt/L);
end 
plot(x,y,'.g',xInt,yInt,'b',xInt,yyInt,':r');

P = A'*A

clear a,b;
for j = 0 : m 
    a(j+1) = yy'*cos(2*pi*j*xx/L)/m; 
    b(j+1) = yy'*sin(2*pi*j*xx/L)/m; 
end 
a, b

clear a,b;
c = fft(yy); 
a = (real(c(1:m+1))/m)' 

b = (-imag(c(1:m+1))/m)'

yy = ifft(c)'  

