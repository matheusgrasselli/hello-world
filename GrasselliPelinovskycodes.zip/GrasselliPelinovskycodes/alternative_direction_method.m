% alternative_direction_method
n = 50; h = 1/n; omega = 0.5; x = 0 : h : 1; y = 0 : h : 1;
 d1 = diag(ones(1,n-1)); d2 = diag(ones(1,n-2),1)+diag(ones(1,n-2),-1);
A = (1+2*omega)*d1 - omega*d2; u = zeros(n+1,n+1);
u(1,:) = sin(pi*x); u(:,1) = sin(2*pi*y'); % boundary values
uN = u; l = 0; nor = 1;
while( (nor > 10^(-6)) & (l < 10000))
    l = l + 1;
    uu = u;
     for m = 2 : n
        u1 = (1-2*omega)*uu(2:n,m)+omega*(uu(2:n,m-1)+uu(2:n,m+1));
        u1 = u1 + omega*uu(1,m)*eye(n-1,1);
        u1 = u1 + omega*h^2*sin(pi*x(m))*sin(pi*y(2:n)');
        u(2:n,m) = inv(A)*u1;
    end
    for k = 2 : n
        u2 = (1-2*omega)*u(k,2:n)'+omega*(u(k-1,2:n)'+uu(k+1,2:n)');
        u2 = u2 + omega*u(k,1)*eye(n-1,1);
        u2 = u2 + omega*h^2*sin(pi*y(k))*sin(pi*x(2:n)');
        uN(k,2:n) = (inv(A)*u2)';
    end
    nor = max(max(abs(uN-uu)));
    u = uN;
end
fprintf('Number of iterations for omega = %f is %d\n',omega,l);
[X,Y] = meshgrid(x,y); mesh(X,Y,u);


