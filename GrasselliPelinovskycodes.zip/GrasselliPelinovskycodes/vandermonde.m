% vandermonde
for n = 10 : 4 : 30
    x = 0.1*(1 : n);
    A = vander(x);
    c = cond(A);
    fprintf('n = %2.0f c = %3.1e \n',n,c);
end