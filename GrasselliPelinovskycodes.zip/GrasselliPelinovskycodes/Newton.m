function [yInt,a] = Newton(x,y,xInt)
% computes the Newton interpolating polynomial
% x,y - row vectors of the same size for the data points
% xInt - row vector for grid points 
% yInt - row vector for interpolated values at xInt
% a - row vector for coefficients of Newton polynomial

n = length(x)-1;
D = zeros(n+1,n+1); % the matrix for Newton divided differences
D(:,1) = y'; % zero-order divided differences
for k = 1 : n
    D(k+1:n+1,k+1) = (D(k+1:n+1,k)-D(k:n,k))./(x(k+1:n+1)-x(1:n-k+1))';
end 
a = diag(D)';
nInt = length(xInt); % computation of interpolated values 
yInt = a(n+1)*ones(1,nInt); % initialization
for k = 1 : n
    yInt = a(n+1-k)+yInt.*(xInt-x(n+1-k)); % nested multiplications
end 
