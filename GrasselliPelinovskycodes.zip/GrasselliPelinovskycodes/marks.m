function [m,s]=marks(x) 

% [m,s]=mean_stdev(x) 
% x is a vector, m and s are scalars 
% the function computes the mean value and standard deviation 
% of the data sample x 

n=length(x); % built-in function for the number of components of a vector

m=sum(x)/n; % built-in function for the sum of the components of a vector 
s=sqrt(sum((x-m).^2)/n); % notice the use componentwise operations 