% forward_differences
n = 50;
x = linspace(0,2*pi,n);
h = x(2)-x(1);
y = sin(x);
y1 = diff(y)/h;                 % numerical derivative
y2 = diff(y,2)/h^2;             % numerical second derivative
y1ex = cos(x);                  % exact derivative
y2ex = -sin(x);                 % exact second derivative
plot(x(1:n-1),y1,'b',x,y1ex,':r'); hold on;
plot(x(1:n-2),y2,'b',x,y2ex,':r');
