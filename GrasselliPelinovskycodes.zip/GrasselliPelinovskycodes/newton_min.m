% newton_min
tol = 0.000001; total = 100; k = 0; epsilon = 1;
x = [1;1]; % initial guess 
while ((epsilon > tol) & (k < total)) % Newton method
    nabla = [20*x(1)*x(2)-10*x(1)-4*x(1)^3;10*x(1)^2-8*x(2)-8*x(2)^3];
    Hessian = [20*x(2)-10-12*x(1)^2 20*x(1);20*x(1) -8-24*x(2)];
    xnew = x - Hessian\nabla; epsilon = norm(xnew-x);
    x=xnew; k = k+1;
end
fprintf('Critical point x = %12.10f, y=%12.10f found after %2.0f iterations \n',...
    x(1),x(2),k);

