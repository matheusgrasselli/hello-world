function x=backsub(U,b)
% solves U*x=b by backward substitution
% U is an n-by-n upper triangular matrix
% b is an n-vector

[n,m]=size(U); x=zeros(n,1);
for i=n:-1:1
    x(i)=(b(i)-U(i,i+1:n)*x(i+1:n))/U(i,i);
end
