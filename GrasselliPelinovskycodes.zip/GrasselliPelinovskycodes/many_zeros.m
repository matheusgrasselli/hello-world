% many_zeros
xInt = 0 : 0.01 : 20;
yInt = cos(xInt).*cosh(xInt) + 1;
plot(xInt,yInt);
xlabel('x');ylabel('y');
tol = 10^(-14); total = 100; a = sign(yInt(1)); j = 1;
% a dense grid on the interval
xInt = 0 : 0.01 : 20; yInt = cos(xInt).*cosh(xInt) + 1;
% iterations of the bisection method
while (j < length(xInt))
    j = j + 1;
    if (sign(yInt(j)) ~= a)
        a = sign(yInt(j));
        % iterations of the Newton method
        k = 0; eps = 1; x = xInt(j-1);
        while ((eps > tol) & (k < total))
            f = cos(x)*cosh(x)+1;
            fDer = sinh(x)*cos(x)-cosh(x)*sin(x);
            xx = x-f/fDer;
            eps = abs(xx-x);
            x = xx;
            k = k+1;
        end
        fprintf('Root x = %12.10f found after %2.0f iterations \n',x,k);
    end
end

