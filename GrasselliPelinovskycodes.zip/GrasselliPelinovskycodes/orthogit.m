function [Q,B] = orthogit(A,X0,maxit)
% orthogonal iterations for the first p eigenvalues of A
% X0 is nxp inital matrix
% Q  is nxp left-orthogonal matrix
% B is pxp block-triangular matrix

X = X0;
for i = 1:maxit
    [Q,R] = QRfactor(X);
    X = A*Q;
end
B = Q'*A*Q;
