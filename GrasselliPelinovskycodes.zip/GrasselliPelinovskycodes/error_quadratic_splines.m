x = 0 : 0.1 : 1; h = x(2)-x(1); n = length(x)-1; 
xInt = 0 : 0.001 : 1; 
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end 
y2 = x.^2; y0 = y2(1:n); m(1) = 0;
firstDifference = (y2(2:n+1)-y2(1:n))./(x(2:n+1)-x(1:n));
for k = 1 : n
    m(k+1) = -m(k)+2*firstDifference(k);
end
kappa = (m(2:n+1)-m(1:n))./(x(2:n+1)-x(1:n));
m = m(1:n);                     % quadratic splines
xx = xInt - x(iInt); 
yInt2 = y0(iInt) + m(iInt).*xx+0.5*kappa(iInt).*xx.^2; 
yEx2 = xInt.^2;
C2 = 3*max(yInt2-yEx2)/h^3
