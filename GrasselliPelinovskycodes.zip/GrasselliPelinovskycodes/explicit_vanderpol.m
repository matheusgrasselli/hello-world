t(1) = 0; y(1) = 0.1; z(1) = 0; mu = 10; T = 50; 
hSpan = 0.02 : 0.02 : 0.04;     % computations with h = 0.02 and h = 0.04
for j = 1 : 2
    h = hSpan(j); n = T/h;
    for k = 1 : n
	    t(k+1) = t(k) + h;
        y(k+1) = y(k) + h*z(k);
        z(k+1) = z(k) + h*(mu*(1-y(k)^2)*z(k)-y(k));
    end 
    if j == 1
        figure(1); plot(t,y,'.b'); hold on;
        axis([0,50,-2.5,2.5]);
        figure(2); plot(y,z,'.r'); 
        axis([-2.5,2.5,-20,20]);
    else
        figure(1);
        plot(t,y,'.g'); hold off;
    end
end



