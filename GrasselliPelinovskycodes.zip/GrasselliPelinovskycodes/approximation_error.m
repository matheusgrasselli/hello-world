% approximation_error
x = 0 : 0.1 : 5; 
n = length(x)-1;
y = exp(-x).*cos(x);
figure(1); hold on;
for m = 1 : 11
    c = polyfit(x,y,m); 
    yy = polyval(c,x);
    E = sum((y-yy).^2) ;
    fprintf('m = %d, E = %6.8f\n',m,E);
    if ((m == 2) | (m == 4) )
        xApr = 0 : 0.001 : 5; 
        yApr = polyval(c,xApr);
        plot(x,y,'g.',xApr,yApr,'b'); 
    end
end
