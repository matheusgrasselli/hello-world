% forward_derivative_higher_accuracy
h = logspace(-1,-10,101);
x0 = ones(size(h));                                    % x_0 = 1
x1 = x0+h;
x2 = x0+2*h;
x3 = x0+3*h;
x4 = x0+4*h;
yDerExact = exp(x0);                                   % f(x) = exp(x)
y0 = exp(x0);
y1 = exp(x1);
y2 = exp(x2);
y3 = exp(x3);
y4 = exp(x4);
yDerForw1 = (y1-y0)./h;                                 % D_1 f(x_0)
eDerForw1 = abs(yDerForw1-yDerExact);
yDerForw2 = (-y2+4*y1-3*y0)./(2*h);                     % D_2 f(x_0)
eDerForw2 = abs(yDerForw2-yDerExact);
yDerForw3 = (2*y3-9*y2+18*y1-11*y0)./(6*h);             % D_3 f(x_0)
eDerForw3 = abs(yDerForw3-yDerExact);
yDerForw4 = (-3*y4+16*y3-36*y2+48*y1-25*y0)./(12*h);    % D_4 f(x_0)
eDerForw4 = abs(yDerForw4-yDerExact);
loglog(h,eDerForw1,'.b',h,eDerForw2,'.r',h,eDerForw3,'.g',h,eDerForw4,'.c');