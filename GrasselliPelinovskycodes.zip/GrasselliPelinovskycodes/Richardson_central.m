% Richardson_central
h = logspace(-1,-7,201);
for k = 1 : length(h)
    Dnum = CentRichExtrap('exp(x)',1,h(k),3);
    eDerCent(k,:) = abs(Dnum-yDerExact);
end
loglog(h,eDerCent,'.');