a = 1; IntExact = tanh(a);  
k = 1; n1 = 10; n2 = 20;
for n = n1 : 2 : n2     % three-point Gauss quadrature
        h = a/n; 
        x1 = linspace(0,a,n+1)+h/2*(1-sqrt(3)/sqrt(5)); 
        x2 = linspace(0,a,n+1)+h/2;
        x3 = linspace(0,a,n+1)+h/2*(1+sqrt(3)/sqrt(5));
        y1 = 1./(cosh(x1).^2);
        y2 = 1./(cosh(x2).^2); 
        y3 = 1./(cosh(x3).^2);
        IntGauss = h*(5*sum(y1(1:n))+8*sum(y2(1:n))+5*sum(y3(1:n)))/18;  
        ErrGauss(k) = abs(IntGauss-IntExact);
        hst(k) = h;  k = k+1; 
    end 
aGauss = polyfit(log(for j = 1 : 2    % two computations
    if (j == 1)
        a = 0.5; n1 = 5; n2 = 500;
    else
        a = 1; n1 = 10; n2 = 1000;
    end
    IntExact = 0.5*(asin(a)+a*sqrt(1-a*a)); k = 1;
    for n = n1 : 1 : n2   % two-point Gaussian quadrature
        h = a/n;
        x1 = linspace(0,a,n+1)+h/2*(1-1/sqrt(3));
        x2 = linspace(0,a,n+1)+h/2*(1+1/sqrt(3));
        y1 = sqrt(1-x1.*x1); y2 = sqrt(1-x2.*x2);
        IntGauss = h*(sum(y1(1:n))+sum(y2(1:n)))/2;
        ErrGauss(k) = abs(IntGauss-IntExact);
        hst(k) = h; k = k+1;
    end
    aGauss = polyfit(log(hst),log(ErrGauss),1);
    powerGauss = aGauss(1)
end
hst),log(ErrGauss),1);
powerGauss = aGauss(1)
