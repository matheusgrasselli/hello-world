% numerical_derivatives
h = logspace(-1,-15,101);
x0 = ones(size(h));                         % x_0 = 1
xn1 = x0-h;
x1 = x0+h;
y0 = exp(x0);                               % f(x) = exp(x)
yDerExact = exp(x0);
yn1 = exp(xn1);
y1 = exp(x1);
yDerForw = (y1-y0)./h;                      % forward difference
eDerForw = abs(yDerForw-yDerExact);
yDerCent = (y1-yn1)./(2*h);                 % central difference
eDerCent = abs(yDerCent-yDerExact);
loglog(h,eDerForw,'.b',h,eDerCent,'.r');