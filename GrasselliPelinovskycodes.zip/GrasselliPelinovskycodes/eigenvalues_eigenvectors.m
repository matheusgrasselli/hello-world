n = 101;
A = 2*diag(ones(1,n)) - diag(ones(1,n-1),1) - diag(ones(1,n-1),-1);
A(1,n) = -1; A(n,1) = -1;
[V,D] = eig(A); lambda = diag(D);
lambda = [lambda(1:2:n);lambda(n-1:-2:2)];      % reorganize eigenvalues
kappa = pi*(0:1:n)/n; lambdaTheory = 4*sin(kappa).^2;
figure(1); plot(kappa,lambdaTheory,'r:',kappa(1:n),lambda','b.')
x = (0:1:n-1)'/(n-1); v1 = V(:,1)/max(V(:,1));  % first five eigenvectors
v2 = V(:,2)/max(V(:,2)); v3 = V(:,3)/max(V(:,3));
v4 = V(:,4)/max(V(:,4)); v5 = V(:,5)/max(V(:,5));
figure(2); plot(x,v1,'b',x,v2,'g',x,v3,'g:',x,v4,'m',x,v5,'m:');