n = 50; x = linspace(0,2*pi,n); 
h = x(2)-x(1); y = sin(x); 
y1 = diff(y)/h; y2 = diff(y,2)/h^2; % numerical derivatives
y1ex = cos(x); y2ex = -sin(x);      % exact derivatives
plot(x(1:n-1),y1,'b',x(2:n),y1,'g',x,y1ex,':r'); hold on;
plot(x(1:n-2),y2,'b',x(3:n),y2,'g',x,y2ex,':r'); hold off;  

