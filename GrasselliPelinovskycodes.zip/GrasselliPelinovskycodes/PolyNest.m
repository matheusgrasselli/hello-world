function [y] = PolyNest(p,x)
% computes the value of the polynomial by using nested multiplication
% p - vector of coefficients for a given polynomial
% x - grid points where the polynomial is to be evaluated
% y - values of the polynomial at x

y = p(1)*ones(size(x));
for k = 2 : length(p)
    y = y.*x + p(k);
end
