% second_derivatives
h = logspace(-1,-7,101);
x0 = ones(size(h));                         % x_0 = 1
xn1 = x0-h;
x1 = x0+h;
x2 = x0+2*h;
y0 = exp(x0);                               % f(x) = exp(x)
yDer2Exact = exp(x0);
yn1 = exp(xn1);
y1 = exp(x1);
y2 = exp(x2);
yDerForw = (y2-2*y1+y0)./(h.^2);            % forward difference
eDerForw = abs(yDerForw-yDer2Exact);
yDerCent = (y1-2*y0+yn1)./(h.^2);           % central difference
eDerCent = abs(yDerCent-yDer2Exact);
loglog(h,eDerForw,'.b',h,eDerCent,'.r');
