format long;
x = linspace(0,2*pi,101); h = x(2) - x(1); n = length(x)-1; 
                % computations of the first method
A1 = 2*diag(ones(n-1,1))-diag(ones(n-2,1),1)-diag(ones(n-2,1),-1);
A2 = h^2*diag(cos(x(2:n))); 
A1(1,1) = 2/3; A1(n-1,n-1) = 2/3;
A1(1,2) = -2/3; A1(n-1,n-2) = -2/3;
A = A1 + A2; [V,D] = eig(A);
[lambda, ind] = sort(diag(D)'/h^2);
disp('The smallest three eigenvalues in the first method are:');
lambda1 = lambda(1:3)
                % computations of the second method
A1 = 2*diag(ones(n+1,1))-diag(ones(n,1),1)-diag(ones(n,1),-1);
A1(1,2) = -2; A1(n+1,n) = -2;
A2 = h^2*diag(cos(x)); A = A1 + A2;  
[V,D] = eig(A); [lambda, ind] = sort(diag(D)'/h^2);
disp('The smallest three eigenvalues in the second method are:');
lambda1 = lambda(1:3)
figure(1); plot(lambda,zeros(size(lambda)),'.');
                % normalization of eigenvectors
vector1 = V(:,ind(1))'; vector1 = vector1/max(abs(vector1)); 
vector2 = V(:,ind(2))'; vector2 = vector2/max(abs(vector2)); 
vector3 = V(:,ind(3))'; vector3 = vector3/max(abs(vector3)); 
figure(2); plot(x,vector1,'b',x,vector2,'g',x,vector3,'r'); 
